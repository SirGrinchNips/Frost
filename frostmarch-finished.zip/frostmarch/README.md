# FROSTMARCH - The Dragon of Skarnveil
An original top-down Nordic action RPG for Game Boy Advance (runs in Delta, mGBA, etc).

**Developed by SirGrinchNips**

Controls: D-pad move | A sword / talk | B shout (cooldown) | SELECT save | START credits

Goal: talk to the Elder, slay 5 wolves to open the northern gate, cross the bridge, defeat Skarnveil.
Skills level by use: SWORD (more damage + max HP) and VOICE (bigger, stronger shout).
Wolves sometimes drop hearts. The dragon enters a furious second phase at half health.

## Build on your phone (no installs)
1. Make a free GitHub repo. Upload `main.c`, `assets.h`, `Makefile`.
2. Add file > Create new file > name it `.github/workflows/build.yml`, paste the contents of that file.
3. Actions tab > "Build ROM" > open the latest run > download artifact `frostmarch-gba`.
4. Unzip in Files (you should see `frostmarch.gba` at the root), open `frostmarch.gba` with Delta.

## Build on a computer
Install devkitARM + gba-tools, then `make`.  
`make test` runs the headless logic tests. `make assets` rebuilds art (edit tools/make_assets.py).

**Important for Delta:** the ROM must be header-fixed with `gbafix`. The Makefile now fails the build if gbafix is missing, so the `.gba` is always valid.
