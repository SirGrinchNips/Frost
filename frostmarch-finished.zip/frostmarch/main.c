/*
 * FROSTMARCH - a top-down Nordic action RPG for the Game Boy Advance.
 * Bare-metal C, no libraries. Build with devkitARM (see README).
 *
 * Controls: D-pad move | A sword / talk | B shout (cooldown) | SELECT save
 * Developed by SirGrinchNips
 */
#include <stdint.h>
typedef uint8_t u8; typedef uint16_t u16; typedef uint32_t u32;
typedef int16_t s16; typedef int32_t s32;
#include "assets.h"

/* ------------------------------------------------------------ hardware */
#ifdef HOST
extern u8 h_io[0x400], h_pal[0x400], h_vram[0x18000], h_oam[0x400], h_sram[0x8000];
#define IO_BASE   h_io
#define PAL_BASE  h_pal
#define VRAM_BASE h_vram
#define OAM_BASE  h_oam
#define SRAM_BASE ((volatile u8*)h_sram)
#else
#define IO_BASE   ((u8*)0x04000000)
#define PAL_BASE  ((u8*)0x05000000)
#define VRAM_BASE ((u8*)0x06000000)
#define OAM_BASE  ((u8*)0x07000000)
#define SRAM_BASE ((volatile u8*)0x0E000000)
#endif
#define R16(o)       (*(volatile u16*)(IO_BASE + (o)))
#define REG_DISPCNT  R16(0x000)
#define REG_VCOUNT   R16(0x006)
#define REG_BG0CNT   R16(0x008)
#define REG_BG1CNT   R16(0x00A)
#define REG_BG0HOFS  R16(0x010)
#define REG_BG0VOFS  R16(0x012)
#define REG_KEYINPUT R16(0x130)
#define REG_WAITCNT  R16(0x204)

#define KEY_A 1
#define KEY_B 2
#define KEY_SELECT 4
#define KEY_START 8
#define KEY_RIGHT 0x10
#define KEY_LEFT 0x20
#define KEY_UP 0x40
#define KEY_DOWN 0x80

/* Delta/mGBA detect the save type from this marker string: 32KB SRAM */
__attribute__((used)) static const char sram_marker[] = "SRAM_V113";

/* ------------------------------------------------------------ vram helpers */
static void copy32(volatile u32 *d, const u32 *s, int n) { while (n-- > 0) *d++ = *s++; }
static void copy16(volatile u16 *d, const u16 *s, int n) { while (n-- > 0) *d++ = *s++; }

#define BG0_MAP(i) (((volatile u16*)(VRAM_BASE + 24 * 0x800))[(i)])  /* 4 screenblocks */
#define BG1_MAP(i) (((volatile u16*)(VRAM_BASE + 28 * 0x800))[(i)])

static void bg0_tile(int tx, int ty, u16 v) {
    int sb = (ty >> 5) * 2 + (tx >> 5);
    BG0_MAP(sb * 1024 + (ty & 31) * 32 + (tx & 31)) = v;
}

/* ------------------------------------------------------------ game data */
enum { ST_SPLASH, ST_TITLE, ST_PLAY, ST_DEAD, ST_WIN, ST_CREDITS };
enum { D_DOWN, D_UP, D_LEFT, D_RIGHT };

typedef struct { u16 a0, a1, a2, pad; } Obj;
static Obj oam[128] __attribute__((aligned(4)));
static int nobj;

typedef struct { int x, y, hp, alive, stun, hurt, ai; } Actor;
typedef struct { int x, y, vx, vy, life; } Fire;
typedef struct { int x, y, life; } Pickup;

static u8 map[1024];
static int state, frame, keys, prev_keys;
static int splash_t;

static Actor pl, dragon, wolf[NUM_WOLVES];
static Fire fire[4];
static Pickup heart[3];
static int pdir, pwalk, pinv, patk, pshout_cd, pshout_fx, pregen;
static int swlv, swxp, shlv, shxp, wolves_killed, dragon_dead, gate_open;
static int dragon_cd, dragon_phase;
static char msg[32];
static int msg_t;
static int has_save;
static int camx, camy;          /* smoothed camera */
static int hitstop;             /* brief freeze on big hits for feedback */

/* ------------------------------------------------------------ utils */
static u32 rng_state = 12345;
static int rnd(void) { rng_state = rng_state * 1103515245u + 12345u; return (int)((rng_state >> 16) & 0x7FFF); }
#define PB_WHITE 1
#define PB_GOLD 2
#define T1(t) ((u16)((t) | (PB_WHITE << 12)))
static int iabs(int v) { return v < 0 ? -v : v; }
static int clamp(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
static int maxhp(void) { return 6 + 2 * (swlv - 1); }
static int sword_dmg(void) { return 1 + (swlv - 1) / 2; }
static int shout_radius(void) { return 42 + 5 * shlv; }
static int shout_dmg(void) { return 2 + shlv / 2; }

static void set_msg(const char *s, int t) {
    int i = 0;
    while (s[i] && i < 30) { msg[i] = s[i]; i++; }
    msg[i] = 0;
    msg_t = t;
}

static int overlap(int ax, int ay, int ahw, int ahh, int bx, int by, int bhw, int bhh) {
    return iabs(ax - bx) <= ahw + bhw && iabs(ay - by) <= ahh + bhh;
}

/* ------------------------------------------------------------ world */
static int solid_px(int x, int y) {
    if (x < 0 || y < 0 || x >= 512 || y >= 512) return 1;
    return mt_solid[map[(y >> 4) * 32 + (x >> 4)]];
}
static int free_box(int x, int y, int hw, int t, int b) {
    return !(solid_px(x - hw, y + t) || solid_px(x + hw, y + t) ||
             solid_px(x - hw, y + b) || solid_px(x + hw, y + b));
}
static void move_box(int *x, int *y, int dx, int dy, int hw, int t, int b) {
    if (dx && free_box(*x + dx, *y, hw, t, b)) *x += dx;
    if (dy && free_box(*x, *y + dy, hw, t, b)) *y += dy;
}

static void draw_mt(int mx, int my) {
    int base = 1 + map[my * 32 + mx] * 4;
    int tx = mx * 2, ty = my * 2;
    bg0_tile(tx, ty, base);         bg0_tile(tx + 1, ty, base + 1);
    bg0_tile(tx, ty + 1, base + 2); bg0_tile(tx + 1, ty + 1, base + 3);
}
static void open_gate(void) {
    gate_open = 1;
    map[GATE_MY * 32 + GATE_MX] = MT_PATH;
    map[GATE_MY * 32 + GATE_MX + 1] = MT_PATH;
    draw_mt(GATE_MX, GATE_MY); draw_mt(GATE_MX + 1, GATE_MY);
}

/* ------------------------------------------------------------ save (SRAM) */
static void sram_write(void) {
    volatile u8 *s = SRAM_BASE;
    u8 d[6] = { (u8)swlv, (u8)swxp, (u8)shlv, (u8)shxp, (u8)wolves_killed, (u8)dragon_dead };
    int i, sum = 0x5A;
    for (i = 0; i < 6; i++) { s[1 + i] = d[i]; sum += d[i]; }
    s[7] = (u8)sum;
    s[0] = 0xA5;
}
static int sram_read(void) {
    volatile u8 *s = SRAM_BASE;
    int i, sum = 0x5A;
    if (s[0] != 0xA5) return 0;
    for (i = 1; i <= 6; i++) sum += s[i];
    if ((u8)sum != s[7]) return 0;
    swlv = s[1]; swxp = s[2]; shlv = s[3]; shxp = s[4]; wolves_killed = s[5]; dragon_dead = s[6];
    if (swlv < 1 || swlv > 9 || shlv < 1 || shlv > 9 || wolves_killed > NUM_WOLVES) return 0;
    return 1;
}

/* ------------------------------------------------------------ setup */
static void reset_world(void) {
    int i, x, y;
    for (i = 0; i < 1024; i++) map[i] = world_map[i];
    gate_open = 0;
    for (y = 0; y < 32; y++) for (x = 0; x < 32; x++) draw_mt(x, y);
    if (wolves_killed >= 5) open_gate();
    for (i = 0; i < NUM_WOLVES; i++) {
        wolf[i].x = wolf_spawn[i][0]; wolf[i].y = wolf_spawn[i][1];
        wolf[i].hp = 3 + (i & 1);          /* some tougher wolves */
        wolf[i].stun = 0; wolf[i].hurt = 0;
        wolf[i].alive = (i >= wolves_killed);
        wolf[i].ai = i % 3;                 /* 0 chase, 1 flank, 2 aggressive */
    }
    dragon.x = DRAGON_HOME_X; dragon.y = DRAGON_HOME_Y;
    dragon.hp = 30; dragon.alive = !dragon_dead; dragon.hurt = 0;
    dragon_cd = 90; dragon_phase = 0;
    for (i = 0; i < 4; i++) fire[i].life = 0;
    for (i = 0; i < 3; i++) heart[i].life = 0;
    pl.x = PLAYER_SX; pl.y = PLAYER_SY; pl.hp = maxhp();
    pdir = D_UP; pinv = 0; patk = 0; pshout_cd = 0; pshout_fx = 0; pregen = 0;
    hitstop = 0;
    camx = pl.x - 120; camy = pl.y - 80;
}

static void start_game(int load) {
    swlv = 1; swxp = 0; shlv = 1; shxp = 0; wolves_killed = 0; dragon_dead = 0;
    if (load) sram_read();
    reset_world();
    REG_DISPCNT = 0x1340;               /* mode0, BG0, BG1, OBJ, 1D mapping */
    set_msg(load ? "WELCOME BACK, WARRIOR" : "SPEAK TO THE ELDER (A)", 200);
    state = ST_PLAY;
}

/* ------------------------------------------------------------ text / HUD */
static int glyph(char c) {
    if (c >= 'a' && c <= 'z') c -= 32;
    if (c < 32 || c > 95) return F_DARK;
    return c - 31;
}
static void put_text(int row, int col, const char *s, int palbank) {
    while (*s && col < 30) { BG1_MAP(row * 32 + col) = (u16)(glyph(*s) | (palbank << 12)); s++; col++; }
}
static void put_num(int row, int col, int v, int palbank) {
    char b[3]; b[0] = (char)('0' + (v / 10) % 10); b[1] = (char)('0' + v % 10); b[2] = 0;
    if (v < 10) b[0] = ' ';
    put_text(row, col, b, palbank);
}
static void clear_bg1(void) { int i; for (i = 0; i < 1024; i++) BG1_MAP(i) = 0; }

static void draw_hud(void) {
    int i, cells = (maxhp() + 1) / 2, cd;
    for (i = 0; i < 60; i++) BG1_MAP(i) = T1(F_DARK);          /* two dark HUD rows */
    put_text(0, 0, "HP", PB_WHITE);
    for (i = 0; i < cells; i++) BG1_MAP(3 + i) = T1(pl.hp > 2 * i ? F_HP_FULL : F_EMPTY);
    put_text(0, 15, "SHOUT", PB_WHITE);
    cd = pshout_cd == 0 ? 6 : 6 - (pshout_cd + 39) / 40;
    for (i = 0; i < 6; i++) BG1_MAP(21 + i) = T1(i < cd ? F_VOICE : F_EMPTY);
    put_text(1, 0, "SWORD", PB_GOLD); put_num(1, 6, swlv, PB_GOLD);
    put_text(1, 9, "VOICE", PB_GOLD); put_num(1, 15, shlv, PB_GOLD);
    put_text(1, 18, "WOLF", PB_GOLD); put_num(1, 23, wolves_killed > 5 ? 5 : wolves_killed, PB_GOLD);
    put_text(1, 25, "/5", PB_GOLD);
    for (i = 0; i < 30; i++) BG1_MAP(19 * 32 + i) = 0;
    if (msg_t > 0) {
        for (i = 0; i < 30; i++) BG1_MAP(19 * 32 + i) = T1(F_DARK);
        put_text(19, 0, msg, PB_WHITE);
    }
}

/* ------------------------------------------------------------ sprites */
static void spr(int x, int y, int size, int tile, int palbank, int hflip) {
    int px = 8 << size;
    if (nobj >= 127 || x <= -px || x >= 240 || y <= -px || y >= 160) return;
    oam[nobj].a0 = (u16)(y & 0xFF);
    oam[nobj].a1 = (u16)((x & 0x1FF) | (hflip ? 0x1000 : 0) | (size << 14));
    oam[nobj].a2 = (u16)(tile | (1 << 10) | (palbank << 12));
    nobj++;
}

static void update_camera(void) {
    int tx = pl.x - 120, ty = pl.y - 80;
    /* soft follow – one third of the way each frame for a smoother feel */
    camx += (tx - camx) / 3;
    camy += (ty - camy) / 3;
    camx = clamp(camx, 0, 512 - 240);
    camy = clamp(camy, 0, 512 - 160);
}

static void build_sprites(void) {
    int i, f;
    nobj = 0;
    /* effects (top) */
    if (state == ST_PLAY || state == ST_DEAD) {
        if (patk > 8) {
            int t = pdir == D_DOWN ? T_SLASH_DOWN : pdir == D_UP ? T_SLASH_UP : T_SLASH_RIGHT;
            int ox = pdir == D_LEFT ? -16 : pdir == D_RIGHT ? 16 : 0;
            int oy = pdir == D_DOWN ? 12 : pdir == D_UP ? -14 : 0;
            spr(pl.x + ox - 8 - camx, pl.y + oy - 8 - camy, 1, t, 0, pdir == D_LEFT);
        }
        if (pshout_fx > 0) spr(pl.x - 16 - camx, pl.y - 16 - camy, 2, T_SHOUT, 0, 0);
    }
    for (i = 0; i < 4; i++)
        if (fire[i].life > 0) spr((fire[i].x >> 8) - 4 - camx, (fire[i].y >> 8) - 4 - camy, 0, T_FIRE, 0, 0);
    /* hearts */
    for (i = 0; i < 3; i++)
        if (heart[i].life > 0)
            spr(heart[i].x - 4 - camx, heart[i].y - 4 - camy, 0, T_FIRE, 0, 0); /* reuse small fire tile as glow */
    /* player */
    if (!(pinv > 0 && (pinv & 4)) && state != ST_DEAD) {
        f = (pwalk >> 3) & 1;
        if (pdir == D_DOWN) spr(pl.x - 8 - camx, pl.y - 8 - camy, 1, f ? T_PL_DOWN1 : T_PL_DOWN0, 0, 0);
        else if (pdir == D_UP) spr(pl.x - 8 - camx, pl.y - 8 - camy, 1, f ? T_PL_UP1 : T_PL_UP0, 0, 0);
        else spr(pl.x - 8 - camx, pl.y - 8 - camy, 1, f ? T_PL_SIDE1 : T_PL_SIDE0, 0, pdir == D_LEFT);
    }
    /* wolves */
    for (i = 0; i < NUM_WOLVES; i++) {
        if (!wolf[i].alive) continue;
        if (wolf[i].hurt > 0 && (wolf[i].hurt & 2)) continue;
        spr(wolf[i].x - 8 - camx, wolf[i].y - 8 - camy, 1,
            ((frame >> 3) & 1) ? T_WOLF1 : T_WOLF0, 0, wolf[i].x > pl.x);
    }
    /* elder */
    spr(NPC_X - 8 - camx, NPC_Y - 8 - camy, 1, T_PL_DOWN0, 1, 0);
    /* dragon */
    if (dragon.alive && !(dragon.hurt > 0 && (dragon.hurt & 2)))
        spr(dragon.x - 16 - camx, dragon.y - 16 - camy, 2, ((frame >> 4) & 1) ? T_DRAGON1 : T_DRAGON0, 0, dragon.x < pl.x);
    for (i = nobj; i < 128; i++) { oam[i].a0 = 0x0200; oam[i].a1 = 0; oam[i].a2 = 0; }
}

/* Runs right after VBlank begins: all VRAM/OAM/IO writes happen here. */
static void present(void) {
    copy32((volatile u32*)OAM_BASE, (const u32*)oam, 256);
    REG_BG0HOFS = (u16)camx; REG_BG0VOFS = (u16)camy;
    if (state != ST_TITLE && state != ST_SPLASH && state != ST_CREDITS) draw_hud();
}

/* ------------------------------------------------------------ combat */
static void spawn_heart(int x, int y) {
    int i;
    for (i = 0; i < 3; i++) if (heart[i].life <= 0) {
        heart[i].x = x; heart[i].y = y; heart[i].life = 420; /* ~7 s */
        return;
    }
}

static void gain_sword_xp(void) {
    swxp++;
    if (swxp >= 4 * swlv && swlv < 9) {
        swlv++; swxp = 0; pl.hp = maxhp(); set_msg("SWORD SKILL INCREASED!", 150);
    }
}
static void gain_voice_xp(void) {
    shxp++;
    if (shxp >= 3 * shlv && shlv < 9) { shlv++; shxp = 0; set_msg("VOICE SKILL INCREASED!", 150); }
}
static void hurt_player(int dmg) {
    if (pinv > 0 || state != ST_PLAY) return;
    pl.hp -= dmg; pinv = 60; pregen = 0;
    if (pl.hp <= 0) { pl.hp = 0; state = ST_DEAD; set_msg("YOU DIED - PRESS A", 9999); }
}
static void kill_wolf(int i) {
    wolf[i].alive = 0; wolves_killed++;
    if ((rnd() & 3) == 0) spawn_heart(wolf[i].x, wolf[i].y); /* 25% heart drop */
    if (wolves_killed == 5 && !gate_open) {
        open_gate(); sram_write(); set_msg("THE NORTHERN GATE OPENS!", 220);
    } else if (wolves_killed < 5) {
        int left = 5 - wolves_killed;
        /* short status */
        if (left == 1) set_msg("ONE WOLF REMAINS!", 120);
        else if (left == 2) set_msg("TWO WOLVES LEFT", 100);
    }
}
static void hit_wolf(int i, int dmg, int kx, int ky) {
    wolf[i].hp -= dmg; wolf[i].hurt = 14; wolf[i].stun = 22;
    move_box(&wolf[i].x, &wolf[i].y, kx, ky, 6, -1, 6);
    if (wolf[i].hp <= 0) kill_wolf(i);
    else hitstop = 3;   /* tiny freeze for impact */
}
static void hit_dragon(int dmg) {
    dragon.hp -= dmg; dragon.hurt = 12;
    hitstop = 4;
    if (dragon.hp <= 15 && dragon_phase == 0) {
        dragon_phase = 1;
        set_msg("SKARNVEIL GROWS FURIOUS!", 160);
        dragon_cd = 20;
    }
    if (dragon.hp <= 0) {
        dragon.alive = 0; dragon_dead = 1; sram_write();
        state = ST_WIN; set_msg("SKARNVEIL FALLS! YOU WIN!", 9999);
    }
}

static void do_sword(void) {
    static const int dx[4] = { 0, 0, -1, 1 }, dy[4] = { 1, -1, 0, 0 };
    int cx = pl.x + dx[pdir] * 14, cy = pl.y + dy[pdir] * 14, i, hits = 0;
    for (i = 0; i < NUM_WOLVES; i++)
        if (wolf[i].alive && overlap(cx, cy, 12, 12, wolf[i].x, wolf[i].y, 7, 6)) {
            hit_wolf(i, sword_dmg(), dx[pdir] * 12, dy[pdir] * 12); hits++;
        }
    if (dragon.alive && overlap(cx, cy, 12, 12, dragon.x, dragon.y, 14, 12)) { hit_dragon(sword_dmg()); hits++; }
    while (hits-- > 0) gain_sword_xp();
}

static void do_shout(void) {
    int r = shout_radius(), dmg = shout_dmg(), i;
    pshout_cd = 220; pshout_fx = 20; gain_voice_xp();
    pinv = 18; /* brief safety after shout */
    for (i = 0; i < NUM_WOLVES; i++) {
        int ddx, ddy, dist2;
        if (!wolf[i].alive) continue;
        ddx = wolf[i].x - pl.x; ddy = wolf[i].y - pl.y;
        dist2 = ddx * ddx + ddy * ddy;
        if (dist2 < r * r) {
            int kx = ddx > 0 ? 4 : -4, ky = ddy > 0 ? 4 : -4, k;
            for (k = 0; k < 7 && wolf[i].alive; k++) {
                if (k == 0) hit_wolf(i, dmg, kx, ky);
                else if (wolf[i].alive) move_box(&wolf[i].x, &wolf[i].y, kx, ky, 6, -1, 6);
            }
            if (wolf[i].alive) wolf[i].stun = 55;
        }
    }
    if (dragon.alive) {
        int ddx = dragon.x - pl.x, ddy = dragon.y - pl.y;
        if (ddx * ddx + ddy * ddy < (r + 14) * (r + 14)) hit_dragon(dmg);
    }
}

/* ------------------------------------------------------------ per-frame logic */
static void spawn_fire(void) {
    int i, dx, dy, m, speed;
    for (i = 0; i < 4; i++) if (fire[i].life <= 0) {
        dx = pl.x - dragon.x; dy = pl.y - (dragon.y + 8);
        m = iabs(dx) > iabs(dy) ? iabs(dx) : iabs(dy);
        if (m == 0) m = 1;
        speed = dragon_phase ? 520 : 380;   /* phase 2 = faster projectiles */
        fire[i].x = dragon.x << 8; fire[i].y = (dragon.y + 8) << 8;
        fire[i].vx = dx * speed / m; fire[i].vy = dy * speed / m;
        fire[i].life = dragon_phase ? 110 : 140;
        return;
    }
}

static void update_play(int pressed) {
    int i, dx = 0, dy = 0, spd, moving = 0;

    if (hitstop > 0) { hitstop--; return; }  /* freeze for impact feedback */

    if (keys & KEY_LEFT)  { dx = -1; pdir = D_LEFT; }
    if (keys & KEY_RIGHT) { dx = 1;  pdir = D_RIGHT; }
    if (keys & KEY_UP)    { dy = -1; pdir = D_UP; }
    if (keys & KEY_DOWN)  { dy = 1;  pdir = D_DOWN; }

    /* slightly faster base speed + smooth diagonal (no extra speed boost) */
    spd = (frame & 1) ? 2 : 1;
    if (patk > 14) spd = 0;                          /* planted during swing windup */
    if (dx && dy) { /* diagonal – still only one axis per sub-step for wall sliding */
        if (free_box(pl.x + dx * spd, pl.y + dy * spd, 5, 1, 7)) {
            pl.x += dx * spd; pl.y += dy * spd;
        } else {
            move_box(&pl.x, &pl.y, dx * spd, dy * spd, 5, 1, 7);
        }
        pwalk++; moving = 1;
    } else if (dx || dy) {
        move_box(&pl.x, &pl.y, dx * spd, dy * spd, 5, 1, 7);
        pwalk++; moving = 1;
    }
    if (!moving) pwalk = 0;

    if (pinv > 0) pinv--;
    if (patk > 0) patk--;
    if (pshout_cd > 0) pshout_cd--;
    if (pshout_fx > 0) pshout_fx--;
    if (++pregen >= 380 && pl.hp < maxhp()) { pl.hp++; pregen = 0; } /* slightly faster regen */
    if (msg_t > 0) msg_t--;

    if ((pressed & KEY_A)) {
        if (overlap(pl.x, pl.y, 24, 24, NPC_X, NPC_Y, 4, 4)) {
            if (dragon_dead) set_msg("THE REALM IS SAFE. THANK YOU!", 220);
            else if (wolves_killed < 5) set_msg("SLAY 5 WOLVES TO OPEN THE GATE", 240);
            else set_msg("SKARNVEIL AWAITS IN THE NORTH", 240);
        } else if (patk == 0) {
            patk = 20;   /* slightly snappier swing */
        }
    }
    if (patk == 16) do_sword();   /* hit earlier in the animation */
    if ((pressed & KEY_B) && pshout_cd == 0) do_shout();
    if (pressed & KEY_SELECT) { sram_write(); set_msg("GAME SAVED", 120); has_save = 1; }

    /* hearts */
    for (i = 0; i < 3; i++) if (heart[i].life > 0) {
        heart[i].life--;
        if (overlap(pl.x, pl.y, 8, 8, heart[i].x, heart[i].y, 6, 6)) {
            if (pl.hp < maxhp()) { pl.hp++; if (pl.hp > maxhp()) pl.hp = maxhp(); }
            heart[i].life = 0;
            set_msg("HEALTH RESTORED", 80);
        }
    }

    /* wolves – varied AI */
    for (i = 0; i < NUM_WOLVES; i++) {
        int wdx, wdy, dist;
        if (!wolf[i].alive) continue;
        if (wolf[i].hurt > 0) wolf[i].hurt--;
        if (wolf[i].stun > 0) { wolf[i].stun--; continue; }
        wdx = pl.x - wolf[i].x; wdy = pl.y - wolf[i].y;
        dist = iabs(wdx) + iabs(wdy);
        if (dist < 110) {
            int sx = 0, sy = 0;
            if (wolf[i].ai == 0) { /* pure chase */
                sx = wdx > 3 ? 1 : wdx < -3 ? -1 : 0;
                sy = wdy > 3 ? 1 : wdy < -3 ? -1 : 0;
            } else if (wolf[i].ai == 1) { /* flank */
                sx = wdx > 3 ? 1 : wdx < -3 ? -1 : 0;
                sy = wdy > 3 ? 1 : wdy < -3 ? -1 : 0;
                if ((frame + i * 7) & 16) { int t = sx; sx = -sy; sy = t; }
            } else { /* aggressive dash every so often */
                sx = wdx > 2 ? 1 : wdx < -2 ? -1 : 0;
                sy = wdy > 2 ? 1 : wdy < -2 ? -1 : 0;
                if ((frame % 40) < 12) { sx *= 2; sy *= 2; } /* short bursts */
            }
            if ((frame % 2) == 0 || wolf[i].ai == 2)
                move_box(&wolf[i].x, &wolf[i].y, sx, sy, 6, -1, 6);
        }
        if (overlap(pl.x, pl.y + 2, 6, 6, wolf[i].x, wolf[i].y, 6, 5)) hurt_player(1);
    }

    /* dragon + fireballs */
    if (dragon.alive) {
        if (dragon.hurt > 0) dragon.hurt--;
        if (pl.y < 100 && pl.x > 170 && pl.x < 340) {
            int move_spd = dragon_phase ? 1 : ((frame & 1) ? 1 : 0);
            if (move_spd) {
                if (dragon.x < pl.x - 10 && dragon.x < 320) dragon.x += move_spd;
                else if (dragon.x > pl.x + 10 && dragon.x > 190) dragon.x -= move_spd;
            }
            if (--dragon_cd <= 0) {
                spawn_fire();
                dragon_cd = dragon_phase ? (38 + rnd() % 18) : (60 + rnd() % 25);
                /* phase 2 sometimes shoots two */
                if (dragon_phase && (rnd() & 1)) spawn_fire();
            }
            if (overlap(pl.x, pl.y, 6, 7, dragon.x, dragon.y + 4, 13, 11)) hurt_player(1);
        }
    }
    for (i = 0; i < 4; i++) if (fire[i].life > 0) {
        fire[i].x += fire[i].vx; fire[i].y += fire[i].vy; fire[i].life--;
        if (solid_px(fire[i].x >> 8, fire[i].y >> 8)) fire[i].life = 0;
        if (overlap(pl.x, pl.y, 6, 7, fire[i].x >> 8, fire[i].y >> 8, 4, 4)) {
            fire[i].life = 0; hurt_player(1);
        }
    }
}

/* ------------------------------------------------------------ screens */
static void draw_splash(void) {
    clear_bg1();
    REG_DISPCNT = 0x0200;     /* BG1 only */
    REG_BG0HOFS = 0; REG_BG0VOFS = 0;
    put_text(7, 6, "DEVELOPED BY", PB_WHITE);
    put_text(9, 5, "SIRGRINCHNIPS", PB_GOLD);
    put_text(14, 7, "FROSTMARCH", PB_WHITE);
    nobj = 0;
    { int i; for (i = 0; i < 128; i++) { oam[i].a0 = 0x0200; oam[i].a1 = 0; oam[i].a2 = 0; } }
}

static void draw_title(void) {
    clear_bg1();
    REG_DISPCNT = 0x0200;     /* BG1 only */
    REG_BG0HOFS = 0; REG_BG0VOFS = 0;
    put_text(3, 10, "FROSTMARCH", PB_GOLD);
    put_text(5, 3, "THE DRAGON OF SKARNVEIL", PB_WHITE);
    put_text(10, 9, "A: NEW GAME", PB_WHITE);
    if (has_save) put_text(12, 9, "B: CONTINUE", PB_WHITE);
    put_text(15, 4, "START: CREDITS", PB_WHITE);
    put_text(17, 1, "A SWORD B SHOUT SELECT SAVE", PB_WHITE);
    nobj = 0;
    { int i; for (i = 0; i < 128; i++) { oam[i].a0 = 0x0200; oam[i].a1 = 0; oam[i].a2 = 0; } }
}

static void draw_credits(void) {
    clear_bg1();
    REG_DISPCNT = 0x0200;
    REG_BG0HOFS = 0; REG_BG0VOFS = 0;
    put_text(4, 6, "DEVELOPED BY", PB_WHITE);
    put_text(6, 5, "SIRGRINCHNIPS", PB_GOLD);
    put_text(10, 4, "A NORDIC TALE OF", PB_WHITE);
    put_text(12, 5, "COURAGE AND ICE", PB_WHITE);
    put_text(16, 6, "PRESS A TO RETURN", PB_WHITE);
    nobj = 0;
    { int i; for (i = 0; i < 128; i++) { oam[i].a0 = 0x0200; oam[i].a1 = 0; oam[i].a2 = 0; } }
}

/* ------------------------------------------------------------ entry points */
void game_init(void) {
    REG_WAITCNT = 0x4317;
    copy32((volatile u32*)(VRAM_BASE + 0x0000), bg_tiles, BG_TILES_WORDS);
    copy32((volatile u32*)(VRAM_BASE + 0x4000), font_tiles, FONT_TILES_WORDS);
    copy32((volatile u32*)(VRAM_BASE + 0x10000), obj_tiles, OBJ_TILES_WORDS);
    copy16((volatile u16*)(PAL_BASE + 0x00), bg_pal, 16);
    copy16((volatile u16*)(PAL_BASE + 0x20), font_pal, 16);
    {   /* bank 2: same font palette but gold text */
        u16 gold[16]; int k;
        for (k = 0; k < 16; k++) gold[k] = font_pal[k];
        gold[1] = font_pal[3];
        copy16((volatile u16*)(PAL_BASE + 0x40), gold, 16);
    }
    copy16((volatile u16*)(PAL_BASE + 0x200), obj_pal0, 16);
    copy16((volatile u16*)(PAL_BASE + 0x220), obj_pal1, 16);
    REG_BG0CNT = 0xD802;      /* prio2, charblock0, screenblock24, 64x64 */
    REG_BG1CNT = 0x1C04;      /* prio0, charblock1, screenblock28, 32x32 */
    has_save = sram_read();
    state = ST_SPLASH; splash_t = 180; /* ~3 seconds */
    frame = 0; prev_keys = 0xFFFF; msg_t = 0;
    draw_splash();
}

void game_frame(void) {
    int pressed;
    keys = ~REG_KEYINPUT & 0x3FF;
    pressed = keys & ~prev_keys;
    prev_keys = keys;
    frame++; rnd();

    switch (state) {
    case ST_SPLASH:
        if (--splash_t <= 0 || pressed) {
            state = ST_TITLE;
            draw_title();
        }
        break;
    case ST_TITLE:
        if (pressed & KEY_A) { clear_bg1(); start_game(0); }
        else if ((pressed & KEY_B) && has_save) { clear_bg1(); start_game(1); }
        else if (pressed & KEY_START) { state = ST_CREDITS; draw_credits(); }
        break;
    case ST_CREDITS:
        if (pressed & KEY_A || pressed & KEY_B || pressed & KEY_START) {
            state = ST_TITLE; draw_title();
        }
        break;
    case ST_PLAY:
        update_play(pressed);
        break;
    case ST_DEAD:
        if (pressed & KEY_A) {
            reset_world();
            state = ST_PLAY; msg_t = 0;
            set_msg("RISE AGAIN, WARRIOR", 120);
        }
        break;
    case ST_WIN:
        if (pressed & KEY_START || pressed & KEY_A) {
            has_save = 1; state = ST_TITLE; draw_title();
        }
        break;
    }
    update_camera();
    if (state == ST_PLAY || state == ST_DEAD || state == ST_WIN) build_sprites();
}

#ifndef HOST
int main(void) {
    game_init();
    for (;;) {
        while (REG_VCOUNT >= 160) {}      /* wait for the frame to be drawn */
        while (REG_VCOUNT < 160) {}       /* wait for VBlank to start */
        present();
        game_frame();
    }
    return 0;
}
#endif
