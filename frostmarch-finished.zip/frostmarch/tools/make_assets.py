#!/usr/bin/env python3
"""Generates source/assets.h (tiles, palettes, map) for FROSTMARCH. Needs Pillow."""
import random, sys, os
from collections import deque
from PIL import Image, ImageDraw, ImageFont

OUT = os.path.join(os.path.dirname(__file__), "..", "assets.h")
PREVIEW = os.path.join(os.path.dirname(__file__), "..", "map_preview.png")

def rgb15(r, g, b):
    return (r >> 3) | ((g >> 3) << 5) | ((b >> 3) << 10)

def pal(colors):
    colors = list(colors) + [(0, 0, 0)] * (16 - len(colors))
    return [rgb15(*c) for c in colors], colors

# ---------------------------------------------------------------- palettes
BG_RGB = [(10, 12, 24),
          (44, 110, 50), (70, 150, 65), (235, 240, 250), (190, 205, 225),
          (130, 130, 140), (85, 85, 95), (40, 90, 170), (90, 150, 220),
          (130, 85, 45), (85, 52, 28), (25, 80, 40), (170, 55, 45),
          (240, 210, 70), (255, 255, 255), (20, 20, 30)]
FONT_RGB = [(0, 0, 0), (255, 255, 255), (20, 20, 30), (240, 200, 60),
            (230, 70, 70), (90, 210, 100), (110, 160, 255), (120, 120, 130)]
OBJ0_RGB = [(0, 0, 0), (240, 190, 150), (25, 20, 35), (60, 90, 170),
            (120, 75, 40), (90, 50, 30), (200, 205, 215), (130, 130, 140),
            (195, 195, 205), (90, 25, 35), (150, 40, 50), (220, 170, 90),
            (250, 220, 60), (255, 255, 255), (230, 60, 40), (110, 220, 250)]
OBJ1_RGB = list(OBJ0_RGB)
OBJ1_RGB[3] = (110, 90, 140)   # elder robe
OBJ1_RGB[5] = (225, 225, 235)  # white hair

# ---------------------------------------------------------------- helpers
def to_tiles(img):
    """P-mode image (w,h multiple of 8) -> list of 8x8 tiles, row-major."""
    w, h = img.size
    tiles = []
    for ty in range(h // 8):
        for tx in range(w // 8):
            tiles.append([[img.getpixel((tx * 8 + x, ty * 8 + y)) for x in range(8)] for y in range(8)])
    return tiles

def tile_words(t):
    words = []
    for y in range(8):
        word = 0
        for x in range(8):
            word |= (t[y][x] & 0xF) << (4 * x)
        words.append(word)
    return words

def outline(img, col=2):
    w, h = img.size
    src = img.copy()
    for y in range(h):
        for x in range(w):
            if src.getpixel((x, y)) == 0:
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < w and 0 <= ny < h and src.getpixel((nx, ny)) not in (0, col):
                        img.putpixel((x, y), col)
                        break

def new(w, h):
    im = Image.new("P", (w, h), 0)
    return im, ImageDraw.Draw(im)

# ---------------------------------------------------------------- BG metatiles (16x16)
NAMES = ["GRASS", "FLOWER", "SNOW", "SNOWROCK", "WATER", "TREE", "PINE", "PATH",
         "WALL", "ROOF", "DOOR", "CLIFF", "FLOOR", "GATE", "BRIDGE"]
M = {n: i for i, n in enumerate(NAMES)}
SOLID = {"WATER", "TREE", "PINE", "WALL", "ROOF", "DOOR", "CLIFF", "GATE"}

def speckle(d, rnd, base_rect, cols, n):
    for _ in range(n):
        x = rnd.randrange(16); y = rnd.randrange(16)
        d.point((x, y), fill=rnd.choice(cols))

def make_metatile(name):
    rnd = random.Random(hash(name) & 0xFFFF if False else sum(map(ord, name)))
    im, d = new(16, 16)
    if name in ("GRASS", "FLOWER", "TREE"):
        d.rectangle((0, 0, 15, 15), fill=1)
        speckle(d, rnd, None, [2, 2, 11], 22)
    if name == "FLOWER":
        for _ in range(4):
            x, y = rnd.randrange(1, 15), rnd.randrange(1, 15)
            d.point((x, y), fill=13); d.point((x + 1, y), fill=14)
    if name in ("SNOW", "SNOWROCK", "PINE"):
        d.rectangle((0, 0, 15, 15), fill=3)
        speckle(d, rnd, None, [4, 4, 14], 18)
    if name == "SNOWROCK":
        d.ellipse((3, 6, 12, 13), fill=5); d.ellipse((4, 6, 10, 10), fill=14)
        d.arc((3, 6, 12, 13), 0, 360, fill=6)
    if name == "WATER":
        d.rectangle((0, 0, 15, 15), fill=7)
        for y in (3, 9, 14):
            for x in range(rnd.randrange(3), 16, 6):
                d.line((x, y, x + 2, y), fill=8)
    if name == "TREE":
        d.rectangle((7, 10, 8, 14), fill=10)
        d.ellipse((2, 0, 13, 11), fill=11); d.ellipse((4, 1, 9, 6), fill=2)
        d.arc((2, 0, 13, 11), 0, 360, fill=15)
    if name == "PINE":
        d.rectangle((7, 12, 8, 15), fill=10)
        for i, w in enumerate((2, 4, 6)):
            top = 1 + i * 4
            d.polygon([(8, top), (8 - w - 1, top + 6), (8 + w, top + 6)], fill=11)
            d.line((8 - w, top + 5, 8 + w - 1, top + 5), fill=14)
    if name == "PATH":
        d.rectangle((0, 0, 15, 15), fill=5)
        for _ in range(7):
            x, y = rnd.randrange(0, 14), rnd.randrange(0, 14)
            d.rectangle((x, y, x + 2, y + 1), fill=rnd.choice([4, 6]))
    if name == "WALL":
        d.rectangle((0, 0, 15, 15), fill=9)
        for y in (3, 7, 11, 15):
            d.line((0, y, 15, y), fill=10)
        for y, off in ((0, 0), (4, 4), (8, 0), (12, 4)):
            for x in range(off, 16, 8):
                d.line((x, y, x, y + 3), fill=10)
    if name == "ROOF":
        d.rectangle((0, 0, 15, 15), fill=12)
        for y in range(1, 16, 4):
            d.line((0, y, 15, y), fill=15)
        for x in range(0, 16, 4):
            d.point((x, 2), fill=14)
    if name == "DOOR":
        d.rectangle((0, 0, 15, 15), fill=9)
        d.rectangle((4, 2, 11, 15), fill=10); d.rectangle((5, 3, 10, 15), fill=9)
        d.point((9, 9), fill=13)
    if name == "CLIFF":
        d.rectangle((0, 0, 15, 15), fill=6)
        d.polygon([(0, 15), (5, 3), (10, 15)], fill=5)
        d.polygon([(7, 15), (12, 5), (16, 15)], fill=4)
        d.line((0, 15, 15, 15), fill=15)
    if name == "FLOOR":
        d.rectangle((0, 0, 15, 15), fill=6)
        d.line((0, 7, 15, 7), fill=15); d.line((7, 0, 7, 15), fill=15)
        d.point((3, 3), fill=5); d.point((11, 11), fill=5)
    if name == "GATE":
        d.rectangle((0, 0, 15, 15), fill=6)
        for x in range(1, 16, 4):
            d.rectangle((x, 0, x + 1, 15), fill=10)
        d.line((0, 5, 15, 5), fill=5); d.line((0, 11, 15, 11), fill=5)
        d.rectangle((0, 0, 15, 1), fill=5)
    if name == "BRIDGE":
        d.rectangle((0, 0, 15, 15), fill=7)
        d.rectangle((1, 0, 14, 15), fill=9)
        for y in range(0, 16, 4):
            d.line((1, y, 14, y), fill=10)
        d.line((1, 0, 1, 15), fill=15); d.line((14, 0, 14, 15), fill=15)
    return im

# ---------------------------------------------------------------- world map
W = H = 32
def build_map(seed):
    rnd = random.Random(seed)
    g = [["GRASS"] * W for _ in range(H)]
    for y in range(H):
        for x in range(W):
            if y < 13:
                g[y][x] = "SNOW"
            elif rnd.random() < 0.07:
                g[y][x] = "FLOWER"
    # river with bridge
    for y in (13, 14, 15):
        for x in range(W):
            g[y][x] = "WATER"
    for y in (13, 14, 15):
        for x in (15, 16):
            g[y][x] = "BRIDGE"
    # lair
    for y in range(0, 7):
        for x in range(10, 22):
            g[y][x] = "CLIFF"
    for y in range(1, 6):
        for x in range(11, 21):
            g[y][x] = "FLOOR"
    g[6][15] = g[6][16] = "GATE"
    # paths
    for y in range(7, 13):
        for x in (15, 16):
            g[y][x] = "PATH"
    for y in range(16, 29):
        for x in (15, 16):
            g[y][x] = "PATH"
    # village houses: roof row + wall row (door in the middle)
    for hx in (5, 11, 20):
        for dx in range(3):
            g[23][hx + dx] = "ROOF"
            g[24][hx + dx] = "WALL"
        g[24][hx + 1] = "DOOR"
    for x in range(5, 24):  # village road
        if g[26][x] in ("GRASS", "FLOWER"):
            g[26][x] = "PATH"
    # scenery
    keep = set()
    for y in range(H):
        for x in (14, 15, 16, 17):
            keep.add((x, y))
    for y in range(22, 31):
        for x in range(3, 26):
            keep.add((x, y))
    for y in range(H):
        for x in range(W):
            n = g[y][x]
            if (x, y) in keep:
                continue
            if n in ("GRASS", "FLOWER") and rnd.random() < 0.13:
                g[y][x] = "TREE"
            elif n == "SNOW":
                r = rnd.random()
                if r < 0.11:
                    g[y][x] = "PINE"
                elif r < 0.15:
                    g[y][x] = "SNOWROCK"
    # border
    for i in range(W):
        for (x, y) in ((i, 0), (i, H - 1), (0, i), (W - 1, i)):
            if g[y][x] in ("GRASS", "FLOWER"):
                g[y][x] = "TREE"
            elif g[y][x] == "SNOW":
                g[y][x] = "PINE"
    # SNOWROCK is walkable decoration; treat as solid too for clarity
    return g

def walkable(g, x, y, gate_open=False):
    n = g[y][x]
    if n == "GATE":
        return gate_open
    return n not in SOLID and n != "SNOWROCK"

def bfs(g, start, gate_open=True):
    seen = {start}; q = deque([start])
    while q:
        x, y = q.popleft()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = x + dx, y + dy
            if 0 <= nx < W and 0 <= ny < H and (nx, ny) not in seen and walkable(g, nx, ny, gate_open):
                seen.add((nx, ny)); q.append((nx, ny))
    return seen

SOLID.add("SNOWROCK")  # rocks block movement

def pick_wolves(g, reach, rnd):
    spots = []
    south = [(x, y) for (x, y) in reach if 17 <= y <= 21 and g[y][x] in ("GRASS", "FLOWER") and abs(x - 15) > 3]
    north = [(x, y) for (x, y) in reach if 7 <= y <= 12 and g[y][x] == "SNOW" and abs(x - 15) > 1]
    rnd.shuffle(south); rnd.shuffle(north)
    def far(p):
        return all(abs(p[0] - q[0]) + abs(p[1] - q[1]) > 4 for q in spots)
    for pool, want in ((south, 3), (north, 5)):
        got = 0
        for p in pool:
            if far(p):
                spots.append(p); got += 1
                if got == want:
                    break
    return spots

seed = 7
while True:
    G = build_map(seed)
    start = (15, 28)
    reach = bfs(G, start, gate_open=True)
    gate_front = (15, 7)
    need = [(15, 7), (15, 5), (20, 1), (11, 5)]
    rnd = random.Random(seed)
    wolves = pick_wolves(G, reach, rnd)
    if all(p in reach for p in need) and len(wolves) == 8:
        break
    seed += 1
print("map seed", seed, "wolves", wolves)

# preview
mt_imgs = [make_metatile(n) for n in NAMES]
rgb_bg = BG_RGB
prev = Image.new("RGB", (W * 16, H * 16))
for y in range(H):
    for x in range(W):
        im = mt_imgs[M[G[y][x]]].copy(); im.putpalette(sum(map(list, rgb_bg), []) + [0] * (768 - 48))
        prev.paste(im.convert("RGB"), (x * 16, y * 16))

# ---------------------------------------------------------------- BG tiles
bg_tiles = [[[0] * 8 for _ in range(8)]]            # tile 0 = blank
for im in mt_imgs:
    bg_tiles.extend(to_tiles(im))                    # TL,TR,BL,BR per metatile

# ---------------------------------------------------------------- font tiles
font = ImageFont.load_default(8)
font_tiles = [[[0] * 8 for _ in range(8)]]          # 0 = fully transparent
for code in range(32, 96):                           # glyph tile index = code - 31
    im, d = new(8, 8)
    d.rectangle((0, 0, 7, 7), fill=2)
    if code != 32:
        d.fontmode = "1"
        d.text((0, -1), chr(code), fill=1, font=font)
    font_tiles.extend(to_tiles(im))
def solid_tile(fill):
    im, d = new(8, 8)
    d.rectangle((0, 0, 7, 7), fill=2)
    d.rectangle((1, 2, 6, 5), fill=fill)
    return to_tiles(im)[0]
font_tiles.append(solid_tile(4))   # 65 HP full
font_tiles.append(solid_tile(7))   # 66 empty
font_tiles.append(solid_tile(3))   # 67 gold
font_tiles.append(solid_tile(6))   # 68 voice
assert len(font_tiles) == 69

# ---------------------------------------------------------------- OBJ sprites
obj = []          # list of tiles
defs = {}         # name -> first tile index
def add(name, img):
    defs[name] = len(obj)
    obj.extend(to_tiles(img))

def player(direction, f):
    im, d = new(16, 16)
    lo = (0, 1) if f == 0 else (1, 0)   # leg raise per frame
    if direction in ("down", "up"):
        d.rectangle((5, 12 - lo[0] + 0, 6, 14 - lo[0]), fill=4)
        d.rectangle((9, 12 - lo[1], 10, 14 - lo[1]), fill=4)
        d.rectangle((4, 7, 11, 11), fill=3); d.line((4, 10, 11, 10), fill=4)
        d.rectangle((3, 8, 3, 10), fill=3); d.point((3, 11), fill=1)
        d.rectangle((12, 8, 12, 10), fill=3); d.point((12, 11), fill=1)
        d.rectangle((5, 1, 10, 6), fill=1)
        if direction == "down":
            d.rectangle((5, 1, 10, 2), fill=5); d.point((5, 3), fill=5); d.point((10, 3), fill=5)
            d.point((6, 4), fill=2); d.point((9, 4), fill=2)
        else:
            d.rectangle((5, 1, 10, 5), fill=5)
    else:  # side, facing right
        d.rectangle((6, 12 - lo[0], 7, 14 - lo[0]), fill=4)
        d.rectangle((8, 12 - lo[1], 9, 14 - lo[1]), fill=4)
        d.rectangle((5, 7, 10, 11), fill=3); d.line((5, 10, 10, 10), fill=4)
        d.rectangle((7, 8, 9, 9), fill=3); d.point((9, 10), fill=1)
        d.rectangle((5, 1, 10, 6), fill=1)
        d.rectangle((5, 1, 10, 2), fill=5); d.rectangle((5, 3, 6, 5), fill=5)
        d.point((9, 4), fill=2)
    outline(im)
    return im

for dname in ("down", "up", "side"):
    for f in (0, 1):
        add(f"PL_{dname.upper()}{f}", player(dname, f))

def wolf(f):
    im, d = new(16, 16)
    o = (0, 1) if f == 0 else (1, 0)
    for x, k in ((4, o[0]), (6, o[1]), (10, o[0]), (12, o[1])):
        d.rectangle((x, 11 - k, x + 1, 14 - k), fill=7)
    d.rectangle((3, 6, 12, 10), fill=7); d.line((4, 10, 11, 10), fill=8)
    d.polygon([(2, 8), (0, 4), (4, 6)], fill=7)
    d.rectangle((11, 4, 14, 8), fill=7); d.rectangle((14, 6, 15, 8), fill=8)
    d.point((12, 3), fill=7); d.point((13, 3), fill=7)
    d.point((13, 5), fill=12); d.point((15, 6), fill=2)
    outline(im)
    return im
for f in (0, 1):
    add(f"WOLF{f}", wolf(f))

def dragon(f):
    im, d = new(32, 32)
    # wings (facing left)
    if f == 0:
        d.polygon([(13, 14), (18, 1), (22, 4), (26, 2), (29, 14)], fill=9)
        d.line((18, 1, 20, 14), fill=10); d.line((26, 2, 24, 14), fill=10)
    else:
        d.polygon([(13, 16), (16, 27), (21, 24), (25, 29), (29, 16)], fill=9)
        d.line((16, 27, 19, 16), fill=10); d.line((25, 29, 24, 16), fill=10)
    d.polygon([(26, 18), (31, 24), (29, 26), (22, 22)], fill=10)    # tail
    d.ellipse((9, 13, 27, 25), fill=10)                              # body
    d.ellipse((11, 19, 24, 25), fill=11)                             # belly
    d.rectangle((11, 24, 13, 29), fill=9); d.rectangle((20, 24, 22, 29), fill=9)  # legs
    d.polygon([(10, 16), (6, 8), (11, 8), (15, 15)], fill=10)        # neck
    d.ellipse((1, 4, 11, 12), fill=10)                               # head
    d.polygon([(1, 8), (0, 12), (6, 12)], fill=10)                   # snout
    d.line((2, 11, 6, 11), fill=11)
    d.polygon([(6, 5), (8, 0), (9, 5)], fill=6); d.polygon([(10, 6), (13, 2), (12, 7)], fill=6)  # horns
    d.point((4, 7), fill=12); d.point((5, 7), fill=12)               # eye
    outline(im)
    return im
for f in (0, 1):
    add(f"DRAGON{f}", dragon(f))

def slash(direction):
    im, d = new(16, 16)
    if direction == "right":
        d.arc((-6, 1, 14, 15), -70, 70, fill=13, width=3); d.arc((-4, 2, 12, 14), -60, 60, fill=6, width=1)
    elif direction == "down":
        d.arc((1, -6, 15, 14), 20, 160, fill=13, width=3); d.arc((2, -4, 14, 12), 30, 150, fill=6, width=1)
    else:
        d.arc((1, 2, 15, 22), 200, 340, fill=13, width=3); d.arc((2, 4, 14, 20), 210, 330, fill=6, width=1)
    return im
for dn in ("right", "down", "up"):
    add(f"SLASH_{dn.upper()}", slash(dn))

im, d = new(32, 32)
d.ellipse((1, 1, 30, 30), outline=15, width=2)
d.ellipse((6, 6, 25, 25), outline=13, width=1)
for a in range(0, 360, 45):
    import math
    x = 15.5 + 14 * math.cos(math.radians(a)); y = 15.5 + 14 * math.sin(math.radians(a))
    d.rectangle((x - 1, y - 1, x + 1, y + 1), fill=13)
add("SHOUT", im)

im, d = new(8, 8)
d.ellipse((0, 0, 7, 7), fill=14); d.ellipse((2, 2, 5, 5), fill=12); d.point((3, 3), fill=13)
add("FIRE", im)

# ---------------------------------------------------------------- emit header
def arr_u32(name, tiles):
    words = [w for t in tiles for w in tile_words(t)]
    body = ",".join("0x%08X" % w for w in words)
    return f"static const u32 {name}[{len(words)}] = {{{body}}};\n#define {name.upper()}_WORDS {len(words)}\n"

def arr_u16(name, vals):
    return f"static const u16 {name}[16] = {{{','.join('0x%04X' % v for v in vals)}}};\n"

with open(OUT, "w") as f:
    f.write("/* AUTO-GENERATED by tools/make_assets.py - do not edit */\n#ifndef ASSETS_H\n#define ASSETS_H\n")
    f.write(arr_u16("bg_pal", pal(BG_RGB)[0]))
    f.write(arr_u16("font_pal", pal(FONT_RGB)[0]))
    f.write(arr_u16("obj_pal0", pal(OBJ0_RGB)[0]))
    f.write(arr_u16("obj_pal1", pal(OBJ1_RGB)[0]))
    f.write(arr_u32("bg_tiles", bg_tiles))
    f.write(arr_u32("font_tiles", font_tiles))
    f.write(arr_u32("obj_tiles", obj))
    for k, v in defs.items():
        f.write(f"#define T_{k} {v}\n")
    f.write("#define F_HP_FULL 65\n#define F_EMPTY 66\n#define F_GOLD 67\n#define F_VOICE 68\n#define F_DARK 1\n")
    f.write(f"#define NUM_MT {len(NAMES)}\n")
    for i, n in enumerate(NAMES):
        f.write(f"#define MT_{n} {i}\n")
    f.write("static const u8 mt_solid[NUM_MT] = {%s};\n" % ",".join("1" if n in SOLID else "0" for n in NAMES))
    f.write("static const u8 world_map[%d] = {%s};\n" % (W * H, ",".join(str(M[G[y][x]]) for y in range(H) for x in range(W))))
    f.write(f"#define PLAYER_SX {15*16+16}\n#define PLAYER_SY {28*16+8}\n")
    f.write(f"#define NPC_X {13*16+8}\n#define NPC_Y {27*16+8}\n")
    f.write("#define DRAGON_HOME_X 256\n#define DRAGON_HOME_Y 48\n")
    f.write("#define GATE_MX 15\n#define GATE_MY 6\n")
    f.write("#define NUM_WOLVES 8\nstatic const s16 wolf_spawn[NUM_WOLVES][2] = {%s};\n" %
            ",".join("{%d,%d}" % (x * 16 + 8, y * 16 + 8) for x, y in wolves))
    f.write("#endif\n")

prev.save(PREVIEW)
print("wrote", OUT, "obj tiles", len(obj), "bg tiles", len(bg_tiles), "font tiles", len(font_tiles))
for k, v in defs.items():
    print(k, v)
