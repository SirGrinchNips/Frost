/* Headless logic test: compiles the real game code against fake hardware memory. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define HOST 1
unsigned char h_io[0x400], h_pal[0x400], h_vram[0x18000], h_oam[0x400], h_sram[0x8000];
#include "../main.c"

static int fails = 0;
#define CHECK(c, ...) do { if (!(c)) { printf("FAIL: " __VA_ARGS__); printf("\n"); fails++; } } while (0)
static void hold(int k) { R16(0x130) = (u16)(~k & 0x3FF); }
static void step(int k, int n) { while (n--) { hold(k); present(); game_frame(); } }
static void tap(int k) { step(k, 1); step(0, 1); }

static void face_and_hit(int wx, int wy) {
    /* stand just left of target, face right, swing */
    pl.x = wx - 14; pl.y = wy; pdir = D_RIGHT;
}

int main(void) {
    int i;
    memset(h_sram, 0xFF, sizeof h_sram);
    R16(0x130) = 0x3FF;
    game_init();
    CHECK(state == ST_SPLASH, "boots to splash");
    /* advance past splash */
    step(0, 200);
    CHECK(state == ST_TITLE && !has_save, "reaches title, no save");
    step(0, 2); tap(KEY_A); CHECK(state == ST_PLAY, "A starts game"); start_game(0);

    /* walking north from spawn: village road -> bridge -> stops at closed gate */
    step(KEY_UP, 900);
    printf("after walking north: x=%d y=%d\n", pl.x, pl.y);
    CHECK(pl.y > 96 && pl.y < 140 && !gate_open, "blocked by closed gate (y=%d)", pl.y);

    /* walls: cannot walk into house wall (roof/wall tiles at y=23-24) */
    pl.x = 6 * 16 + 8; pl.y = 24 * 16 + 28; step(KEY_UP, 50);
    CHECK(pl.y >= 24 * 16 + 4, "house wall solid (y=%d)", pl.y);

    /* elder dialogue */
    state = ST_PLAY; msg_t = 0; pl.hp = maxhp(); pinv = 0;
    pl.x = NPC_X + 10; pl.y = NPC_Y; tap(KEY_A);
    CHECK(msg_t > 0 && msg[0] == 'S', "elder talks");

    /* kill wolves; gate opens at 5 */
    for (i = 0; i < NUM_WOLVES; i++) {
        int guard = 0;
        while (wolf[i].alive && guard++ < 400) {
            face_and_hit(wolf[i].x, wolf[i].y);
            pinv = 100; pl.hp = maxhp();
            if (!free_box(pl.x, pl.y, 5, 1, 7)) { pl.x = wolf[i].x + 14; pdir = D_LEFT; }
            tap(KEY_A); step(0, 24);
        }
        CHECK(!wolf[i].alive, "wolf %d killed", i);
        if (i == 3) CHECK(!gate_open, "gate still closed after 4");
        if (i == 4) CHECK(gate_open && map[GATE_MY * 32 + GATE_MX] == MT_PATH, "gate open after 5");
    }
    CHECK(swlv > 1, "sword leveled (lv %d)", swlv);
    printf("wolves=%d swlv=%d swxp=%d\n", wolves_killed, swlv, swxp);

    /* shout: cooldown + xp */
    pshout_cd = 0; int xp0 = shxp + shlv * 100; tap(KEY_B);
    CHECK(pshout_cd >= 200 && shxp + shlv * 100 > xp0, "shout fires");
    tap(KEY_B); CHECK(pshout_cd > 180, "shout on cooldown");

    /* save + dragon */
    pl.x = 15 * 16 + 16; pl.y = 8 * 16; step(KEY_UP, 200);
    CHECK(pl.y < 96, "entered lair (y=%d)", pl.y);
    {
        int guard = 0, fired = 0;
        while (state == ST_PLAY && guard++ < 8000) {
            pl.x = dragon.x + 22; pl.y = dragon.y + 4; pdir = D_LEFT;
            if (pl.y > 90) pl.y = 90;
            if (pinv == 0 && pl.hp <= 1) pl.hp = maxhp();
            for (int f = 0; f < 4; f++) if (fire[f].life > 0) fired = 1;
            tap(KEY_A); step(0, 20);
        }
        CHECK(fired, "dragon shot fireballs");
        CHECK(state == ST_WIN, "dragon defeated -> win (dragon hp %d)", dragon.hp);
    }
    CHECK(dragon_dead && h_sram[0] == 0xA5, "win auto-saved");

    /* title -> continue restores */
    tap(KEY_START);
    CHECK(state == ST_TITLE && has_save, "back to title with save");
    swlv = 1; wolves_killed = 0; dragon_dead = 0;
    tap(KEY_B);
    CHECK(state == ST_PLAY && wolves_killed == NUM_WOLVES && dragon_dead && gate_open && !dragon.alive,
          "continue restored (wolves %d, dead %d)", wolves_killed, dragon_dead);

    /* death + respawn */
    tap(KEY_START); /* ignored in play */
    start_game(0);
    pl.hp = 1; pinv = 0; wolf[0].x = pl.x; wolf[0].y = pl.y; wolf[0].alive = 1; wolf[0].stun = 0;
    step(0, 5);
    CHECK(state == ST_DEAD, "player dies");
    tap(KEY_A);
    CHECK(state == ST_PLAY && pl.hp == maxhp() && pl.x == PLAYER_SX, "respawn");

    /* corrupt save is rejected */
    h_sram[3] ^= 0x55; CHECK(!sram_read(), "bad checksum rejected");

    /* fuzz: random inputs for a long time, watch for OOB (run under ASAN/UBSAN) */
    srand(1); start_game(0);
    for (i = 0; i < 300000; i++) {
        static int k = 0;
        if ((i % 20) == 0) k = rand() & 0x3FF & ~(KEY_START);
        if ((i % 3000) == 0) { pl.x = rand() % 512; pl.y = rand() % 512; if (solid_px(pl.x, pl.y)) { pl.x = PLAYER_SX; pl.y = PLAYER_SY; } }
        step(k, 1);
        if (state == ST_DEAD) tap(KEY_A);
        if (state == ST_WIN) { tap(KEY_START); tap(KEY_B); if (state != ST_PLAY) start_game(0); }
        if (state == ST_SPLASH) step(0, 5);
        if (state == ST_CREDITS) tap(KEY_A);
        CHECK(nobj <= 128, "oam overflow");
        if (fails) break;
    }
    printf("fuzz done, state=%d swlv=%d shlv=%d wolves=%d\n", state, swlv, shlv, wolves_killed);

    /* VRAM sanity: BG1 map entries only reference valid font tiles; BG0 only valid bg tiles */
    for (i = 0; i < 1024; i++) {
        u16 e = BG1_MAP(i); CHECK((e & 0x3FF) < 69, "bg1 tile idx %d", e & 0x3FF);
        u16 g = BG0_MAP(i); CHECK((g & 0x3FF) < 61, "bg0 tile idx %d", g & 0x3FF);
    }
    { const char *all[] = {
        "SLAY 5 WOLVES TO OPEN THE GATE","SKARNVEIL AWAITS IN THE NORTH",
        "THE REALM IS SAFE. THANK YOU!","WELCOME BACK, WARRIOR",
        "SPEAK TO THE ELDER (A)","THE NORTHERN GATE OPENS!",
        "SKARNVEIL FALLS! YOU WIN!","SWORD SKILL INCREASED!",
        "VOICE SKILL INCREASED!","YOU DIED - PRESS A","GAME SAVED",
        "DEVELOPED BY","SIRGRINCHNIPS","RISE AGAIN, WARRIOR",
        "HEALTH RESTORED","SKARNVEIL GROWS FURIOUS!",
        "ONE WOLF REMAINS!","TWO WOLVES LEFT"
      };
      for (i = 0; i < (int)(sizeof all / sizeof *all); i++) CHECK(strlen(all[i]) <= 30, "msg too long: %s", all[i]); }
    printf(fails ? "\n%d FAILURES\n" : "\nALL TESTS PASSED\n", fails);
    return fails != 0;
}
